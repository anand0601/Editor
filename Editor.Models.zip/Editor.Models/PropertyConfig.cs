﻿namespace Editor.Models
{
    public class PropertyConfig
    {
        public int Id { get; set; }
        public ControlConfig ControlConfig { get; set; }
        public Property Property { get; set; }
        public string Value { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editor.Models
{
    public class LookupItemConfig
    {
        public int Id { get; set; }
        public ControlConfig ControlConfig { get; set; }
        public LookupItem LookupItem { get; set; }
    }
}

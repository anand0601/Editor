﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editor.Models
{
    public class LetterConfig
    {
        public int Id { get; set; }
        public Portfolio Portfolio { get; set; }
        public BusinessApplication BusinessApplication { get; set; }
        public LineOfBusiness LineOfBusiness { get; set; }
        public Category Category { get; set; }
        public Letter Letter { get; set; }
        public ICollection<SectionConfig> SectionConfigs { get; set; }

    }
}

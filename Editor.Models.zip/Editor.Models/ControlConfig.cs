﻿using System.Collections.Generic;

namespace Editor.Models
{
    public class ControlConfig
    {
        public int Id { get; set; }
        public SectionConfig SectionConfig { get; set; }
        public Control Control { get; set; }
        public int DisplayOrder { get; set; }
        public ICollection<ControlConfig> Childs { get; set; }
        public ICollection<PropertyConfig> PropertyConfigs { get; set; }
        public ICollection<ValidationConfig> ValidationConfigs { get; set; }
        public ICollection<OutputConfig> OutputConfigs { get; set; }
        public ICollection<LookupItemConfig> LookupItemConfigs { get; set; }
        public ICollection<DataFilterConfig> DataFilterConfigs { get; set; }
    }
}
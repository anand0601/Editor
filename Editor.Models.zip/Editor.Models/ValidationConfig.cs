﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editor.Models
{
    public class ValidationConfig
    {
        public int Id { get; set; }
        public ControlConfig ControlConfig { get; set; }

        public Validation Validation { get; set; }

    }
}

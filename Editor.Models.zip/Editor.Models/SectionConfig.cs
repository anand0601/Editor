﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editor.Models
{
    public class SectionConfig
    {
        public int Id { get; set; }
        public LetterConfig LetterConfig { get; set; }
        public Section Section { get; set; }
        public ICollection<ControlConfig> ControlConfigs { get; set; }
        public int DisplayOrder { get; set; }
    }
}

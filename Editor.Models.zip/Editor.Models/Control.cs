﻿using System.Collections.Generic;

namespace Editor.Models
{
    public class Control
    {
        public int Id { get; set; }
        public string Name { get; set; }
        
    }
}
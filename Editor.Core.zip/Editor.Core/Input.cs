﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editor.Core
{
    public class Input<Req> : IInput<Req>
    {
        public Req Request { get; set; }

        public Input(Req request)
        {
            this.Request = request;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editor.Core
{
    public class Output<R, S> : IOutput<R, S> 
    {
        public R Result { get; set; }
        public S Status { get; set; }

        public Output(R result, S status)
        {
            this.Result = result;
            this.Status = status;
        }
    }
}

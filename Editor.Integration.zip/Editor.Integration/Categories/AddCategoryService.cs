﻿using Editor.Core;
using Editor.Integration;
using Editor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editor.Integration.Categories
{
    public class AddCategoryService : IIntegrationService<Category, Category, string>
    {
        public Output<Category, string> Execute(Input<Category> input)
        {
            var category = new Category() { Id = 1, Name = "PIP" };

            var categoryOutput = new Output<Category, string>(category, "only one Category");

            return categoryOutput;
        }
    }
}

﻿using Editor.Core;
using Editor.Models;
using System.Collections.Generic;
using System.Linq;

namespace Editor.Integration.Categories
{
    public class GetCategoriesWithLettersService : IIntegrationService<Category, List<Category>, string>
    {
        private readonly EditorContext dbContext = null;

        public GetCategoriesWithLettersService()
        {
            dbContext = new EditorContext();
        }

        public Output<List<Category>, string> Execute(Input<Category> input)
        {
            var categories = new List<Category>(); //{
            //new Category()
            //{
            //    Id =1,Name="Homeowners",
            //    DisplayName ="Homeowners",
            //    Description = "Homeowners Description",
            //    Letters = new List<Models.Letter>()
            //        {
            //            new Models.Letter()
            //            {
            //                Id=11,
            //                Name="DL02"
            //            },
            //            new Models.Letter()
            //            {
            //                Id=11,
            //                Name="DL03"
            //            },
            //        }
            //},
            //new Category(){Id=2,Name="Legal",DisplayName="Legal",Description = "Legal Description"},
            //new Category(){Id=2,Name="Adjuster",DisplayName="Adjuster",Description = "Adjuster Description"}
            //};

            var dbCategories = (from jc in dbContext.LetterConfigs select jc.Category).ToList();
          
            foreach (Category dbCategory in dbCategories)
            {
                var dbLetters = (from jc in dbContext.LetterConfigs
                                 where jc.Category.Name.Equals(dbCategory.Name)
                                 select jc.Letter).ToList();

                categories.Add(new Category()
                {
                    Id = dbCategory.Id,
                    Name = dbCategory.Name,
                    DisplayName = dbCategory.DisplayName,
                    Description = null,
                    Letters = dbLetters
                });
            }

            var categoryOutput = new Output<List<Category>, string>(categories, "List of Category with Letters");

            return categoryOutput;
        }
    }
}
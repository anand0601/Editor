﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Editor.Core;
using Editor.Integration;
using Editor.Models;

namespace Editor.Integration.Categories
{
    public class DeleteCategoryService : IIntegrationService<Category, Category, string>
    {
        public Output<Category, string> Execute(Input<Category> input)
        {
            var category = new Category() { Id = 1, Name = "PIP" };

            var categoryOutput = new Output<Category, string>(category, "only one Category");

            return categoryOutput;
        }
    }
}

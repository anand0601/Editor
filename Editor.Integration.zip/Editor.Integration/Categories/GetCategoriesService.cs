﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Editor.Core;
using Editor.Integration;
using Editor.Models;

namespace Editor.Integration.Categories
{
    public class GetCategoriesService : IIntegrationService<Category, List<Category>, string>
    {
        private readonly EditorContext dbContext = null;


        public GetCategoriesService()
        {
            dbContext = new EditorContext();
        }


        public Output<List<Category>, string> Execute(Input<Category> input)
        {
            var categories = new List<Category>() {

            new Category(){Id=1,Name="PIP",DisplayName="PIP",Description = "PIP Description"},
            new Category(){Id=2,Name="Legal",DisplayName="Legal",Description = "Legal Description"},
            new Category(){Id=2,Name="Adjuster",DisplayName="Adjuster",Description = "Adjuster Description"}

            };

            var dbCategories = (from c in dbContext.Categories
                                select c).ToList();

            foreach (Category dbCategory in dbCategories)
            {
                categories.Add(new Category()
                {
                    Id = dbCategory.Id,
                    Name = dbCategory.Name,
                    DisplayName = dbCategory.DisplayName,
                    Description = null
                });
            }

            var categoryOutput = new Output<List<Category>, string>(categories, "List of Category");

            return categoryOutput;
        }
    }
}

﻿using Editor.Core;
using Editor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editor.Integration.Letters
{
    public class AddLetterService //: IIntegrationService<Letter, Letter, string>
    {
        private readonly EditorContext dbContext = null;


        public AddLetterService()
        {
            dbContext = new EditorContext();
        }

        public void Execute(Letter letter)
        {
            dbContext.Letters.Add(letter);

            dbContext.SaveChanges();

            //var letterOutput = new Output<Letter, string>(input.Request, "Added Letter");

            //return letterOutput;
        }
    }
}

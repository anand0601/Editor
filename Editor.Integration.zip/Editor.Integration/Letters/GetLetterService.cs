﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Editor.Core;
using Editor.Integration;
using Editor.Models;

namespace Editor.Integration.Letters
{
    public class GetLetterService //: IIntegrationService<int,Letter, string>
    {
        private readonly EditorContext dbContext = null;


        public GetLetterService()
        {
            dbContext = new EditorContext();
        }


        public Letter Execute(int id)
        {
            var dbLetter = (from l in dbContext.Letters
                             where l.Id.Equals(id)
                             select l).FirstOrDefault();

            var letter = new Letter()
            {
                Id = dbLetter.Id,
                Name = dbLetter.Name,
                Description = dbLetter.Description
            };
            //var letterOutput = new Output<Letter, string>(new Letter() { Id = dbLetter.Id, Name = dbLetter.Name, Description = dbLetter.Description}, "get letter by Id");

            return letter;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editor.Integration.Letters
{
    public class DeleteLetterService
    {

        private readonly EditorContext dbContext = null;


        public DeleteLetterService()
        {
            dbContext = new EditorContext();
        }

        public void Execute(int id)
        {
            var dbLetter = dbContext.Letters.Where(l => l.Id.Equals(id)).FirstOrDefault();

            dbContext.Letters.Remove(dbLetter);

            dbContext.SaveChanges();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Editor.Core;
using Editor.Integration;
using Editor.Models;

namespace Editor.Integration.Letters
{
    public class GetLettersService //: IIntegrationService<Letter, List<Letter>, string>
    {
        private readonly EditorContext dbContext = null;


        public GetLettersService()
        {
            dbContext = new EditorContext();
        }


        public IEnumerable<Letter> Execute()
        {
            var letters = new List<Letter>();

            //{

            //new Letter(){ Id=1,Name="PIP",Description = "PIP Description"},
            //new Letter(){Id=2,Name="Legal",Description = "Legal Description"},
            //new Letter(){Id=3,Name="Adjuster",Description = "Adjuster Description"}

            //};

            var dbLetters = (from l in dbContext.Letters
                                select l).ToList();

            foreach (Letter dbLetter in dbLetters)
            {
                letters.Add(new Letter()
                {
                    Id = dbLetter.Id,
                    Name = dbLetter.Name,
                    Description = dbLetter.Description
                });
            }

            //var letterOutput = new Output<List<Letter>, string>(letters, "List of Letter");

            return letters;
        }
    }
}

﻿using Editor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Editor.Core;
using System.Data.Entity;

namespace Editor.Integration.Letters
{
    public class UpdateLetterService //: IIntegrationService<Letter,Letter, string>
    {
        private readonly EditorContext dbContext = null;


        public UpdateLetterService()
        {
            dbContext = new EditorContext();
        }

        public void Execute(Letter letter)
        {


            var dbLetter = (from l in dbContext.Letters
                            where l.Id.Equals(letter.Id)
                            select l).FirstOrDefault();

            dbLetter.Name = letter.Name;
            dbLetter.Description = letter.Description;

            dbContext.SaveChanges();

        }
    }
}




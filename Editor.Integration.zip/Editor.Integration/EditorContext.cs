﻿using Editor.Models;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;


namespace Editor.Integration
{
    public class EditorContext : DbContext
    {
        public EditorContext() : base("EditorContext")
        {
        }

        public DbSet<Portfolio> Portfolios { get; set; }
        public DbSet<BusinessApplication> BusinessApplications { get; set; }
        public DbSet<LineOfBusiness> LineOfBusinesses { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Letter> Letters { get; set; }
        public DbSet<Section> Sections { get; set; }
        public DbSet<Control> Controls { get; set; }
        public DbSet<Property> Properties { get; set; }
        public DbSet<Validation> Validations { get; set; }
        public DbSet<Output> Outputs { get; set; }
        public DbSet<OutputType> OutputTypes { get; set; }
        public DbSet<DataFilter> DataFilters { get; set; }
        public DbSet<LookupItem> LookupItems { get; set; }
      
        public DbSet<LetterConfig> LetterConfigs { get; set; }
        public DbSet<SectionConfig> SectionConfigs { get; set; }
        public DbSet<ControlConfig> ControlConfigs { get; set; }
        public DbSet<PropertyConfig> PropertyConfigs { get; set; }
        public DbSet<ValidationConfig> ValidationConfigs { get; set; }
        public DbSet<OutputConfig> OutputConfigs { get; set; }
        public DbSet<LookupItemConfig> LookupItemConfigs { get; set; }
        public DbSet<DataFilterConfig> DataFilterConfigs { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }

    }
}

﻿using Editor.Core;
using Editor.Models;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;

namespace Editor.Integration.Sections
{
    public class GetSectionsForLetter : IIntegrationService<Section, List<SectionConfig>, string>
    {
        private readonly EditorContext dbContext = null;

        public GetSectionsForLetter()
        {
            dbContext = new EditorContext();
        }
        public Output<List<SectionConfig>, string> Execute(Input<Section> input)
        {
            //IEnumerable<SectionConfig> sectionConfigs = (from lc in dbContext.LetterConfigs
            //                     where lc.Letter.Name.Equals("No Coverage Letter")
            //                     select lc.SectionConfigs).AsEnumerable<SectionConfig>();

            //var dbSectionConfigs = from lc in dbContext.LetterConfigs
            //                        from sc in lc.SectionConfigs
            //                        from cc in sc.ControlConfigs
            //                        from pc in cc.PropertyConfigs
            //                        select lc.SectionConfigs.ToList<Models.SectionConfig>();


            //var letterConfigs = dbContext.LetterConfigs;


            //var sectionCon = letterConfigs

            //    .Select(lc=>lc.SectionConfigs.SelectMany(dbContext.SectionConfigs =>dbContext.SectionConfigs.);

            //var sections = dbContext.SectionConfigs
            //    .Include(sc => sc.Section)
            //    .Include(a => a.ControlConfigList)
            //    .Include(b=> b.ControlConfigList.Select(e=>e.Control))
            //    .Include(c => c.ControlConfigList.Select(f => f.PropertyConfigList))
            //    .Include(d => d.ControlConfigList.Select(g => g.PropertyConfigList.Select(pc=>pc.Property)))
            //    .ToList();

            var sections = dbContext.SectionConfigs
               .Include(sc => sc.Section)
               .Include(b => b.ControlConfigs.Select(e => e.Control))
               .Include(c => c.ControlConfigs.Select(f => f.PropertyConfigs))
               .Include(d => d.ControlConfigs.Select(g => g.PropertyConfigs.Select(pc => pc.Property)))
               .ToList();



            //var sections = new List<SectionConfig>();
            //{
            //    new Models.Section()
            //    {
            //        Id=111,
            //        Name="Exposure Information",
            //        Controls = new List<Models.Control>()
            //        {
            //            new Models.Control(){Id=1111, LabelText="Exposure Name",Type="lableDropDown"},
            //            new Models.Control(){Id=1112, LabelText="Exposure Type",Type="lableDropDown"}
            //        }
            //    },
            //    new Models.Section()
            //    {
            //        Id=112,
            //        Name="Address",
            //        Controls = new List<Models.Control>()
            //        {
            //            new Models.Control(){Id=1121, LabelText="Primary Addressee",Type="lableDropDown"},
            //            new Models.Control(){Id=1122, LabelText="Secondary Addressee",Type="lableDropDown"},
            //            new Models.Control(){Id=1123, LabelText="Author",Type="lableDropDown"}
            //        }
            //    },
            //    new Models.Section()
            //    {
            //        Id=113,
            //        Name="Re Section",
            //        Controls = new List<Models.Control>()
            //        {
            //            new Models.Control(){Id=1131, LabelText="Your Claim No.",Type="lableTextBox"},
            //            new Models.Control(){Id=1132, LabelText="Your Client",Type="lableTextBox"},
            //            new Models.Control(){Id=1133, LabelText="Claimant",Type="lableDropDown"}
            //        }
            //    },
            //    new Models.Section()
            //    {
            //        Id=114,
            //        Name="Body Section",
            //        Controls = new List<Models.Control>()
            //        {
            //            new Models.Control(){Id=1141, LabelText="Statement of Fact",Type="lableTextBox"},
            //            new Models.Control(){Id=1142, LabelText="Certified Mail indicator",Type="lableCheckbox"}
            //        }
            //    },
            //    new Models.Section()
            //    {
            //        Id=115,
            //        Name="Output Profile Section",
            //        Controls = new List<Models.Control>()
            //        {
            //            new Models.Control(){Id=1151, LabelText="Print",Type="lableDropDown"}
            //        }
            //    },
            //};


            var sectionOutput = new Output<List<SectionConfig>, string>(sections, "List of Sections for a letter");

            return sectionOutput;
        }
    }
}
﻿using Editor.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Editor.Integration
{
    public interface IIntegrationService<Req, R, S> : IService<Input<Req>, Output<R, S>>
         where Req : class
         where R : class
    {

    }
}

namespace Editor.Integration.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.Control", "LabelText");
            DropColumn("dbo.Control", "Type");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Control", "Type", c => c.String());
            AddColumn("dbo.Control", "LabelText", c => c.String());
        }
    }
}

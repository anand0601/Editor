namespace Editor.Integration.Migrations
{
    using Models;
    using System.Collections.Generic;
    using System.Data.Entity.Migrations;

    internal sealed class Configuration : DbMigrationsConfiguration<Editor.Integration.EditorContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(Editor.Integration.EditorContext context)
        {
            context.Portfolios.AddOrUpdate(p => p.Id,
                new Portfolio { Id = 1, Name = "Claims", DisplayName = "Claims" },
                new Portfolio { Id = 2, Name = "Underwritting", DisplayName = "Underwritting" }

                );

            context.BusinessApplications.AddOrUpdate(ba => ba.Id,
                new BusinessApplication { Id = 1, Name = "CC", DisplayName = "Claim Center" },
                new BusinessApplication { Id = 2, Name = "PC", DisplayName = "Policy Center" },
                new BusinessApplication { Id = 3, Name = "BC", DisplayName = "Billing Center" }

                );

            context.LineOfBusinesses.AddOrUpdate(lob => lob.Id,
                new LineOfBusiness { Id = 1, Name = "GC", DisplayName = "General Claims" },
                new LineOfBusiness { Id = 2, Name = "WCC", DisplayName = "Workers Comp Claims" }
                );

            context.Categories.AddOrUpdate(c => c.Id,
                new Category { Id = 1, Name = "GC_BODILY_INJURY", DisplayName = "Bodily Injury" },
                new Category { Id = 2, Name = "GC_LEGAL", DisplayName = "Legal" }
                );

            context.Letters.AddOrUpdate(l => l.Id,
                new Letter { Id = 1, Name = "No Coverage Letter", Description = "No Coverage Letter" },
                new Letter { Id = 2, Name = "No Pay No Play", Description = "No Pay No Play" }
                );

            context.Sections.AddOrUpdate(s => s.Id,
                new Section { Id = 1, Name = "Exposure Information", Description = "Exposure Information" },
                new Section { Id = 2, Name = "Address", Description = "Address" },
                new Section { Id = 3, Name = "Re Section", Description = "Re Section" },
                new Section { Id = 4, Name = "Body Section", Description = "Body Section" },
                new Section { Id = 5, Name = "Output Profile Section", Description = "Output Profile Section" },
                new Section { Id = 6, Name = "CC Section", Description = "CC Section" }
                );

            context.Controls.AddOrUpdate(ctrl => ctrl.Id,
                new Control { Id = 1, Name = "LabelTextbox" },
                new Control { Id = 2, Name = "LabelCheckbox" },
                new Control { Id = 3, Name = "LabelDropDown" },
                new Control { Id = 4, Name = "WiredDropDown" }
                );

            context.Properties.AddOrUpdate(prop => prop.Id,
                new Property { Id = 1, Name = "LabelText" },
                new Property { Id = 2, Name = "Width" }
                );

            //context.LetterConfigs.AddOrUpdate(lc => lc.Id,
            //    new LetterConfig
            //    {
            //        Id = 1,
            //        Portfolio = new Portfolio { Id = 1, Name = "Claims", DisplayName = "Claims" },
            //        BusinessApplication = new BusinessApplication { Id = 1, Name = "CC", DisplayName = "Claim Center" },
            //        LineOfBusiness = new LineOfBusiness { Id = 1, Name = "GC", DisplayName = "General Claims" },
            //        Category = new Category { Id = 1, Name = "GC_BODILY_INJURY", DisplayName = "Bodily Injury" },
            //        Letter = new Letter { Id = 1, Name = "No Coverage Letter", Description = "No Coverage Letter" },
            //        SectionConfigs = new List<SectionConfig>
            //        {
            //            new SectionConfig
            //            {
            //                Id = 1,
            //                Section = new Section { Id = 1, Name = "Exposure Information", Description="Exposure Information"},
            //                DisplayOrder = 1,
            //            },
            //            new SectionConfig
            //            {
            //                Id = 2,
            //                Section = new Section { Id = 2, Name = "Address", Description="Address"},
            //                DisplayOrder = 2,
            //            },
            //            new SectionConfig
            //            {
            //                Id = 3,
            //                Section = new Section { Id = 3, Name = "Re Section", Description="Re Section"},
            //                DisplayOrder = 3,
            //            },
            //            new SectionConfig
            //            {
            //                Id = 4,
            //                Section = new Section { Id = 4, Name = "Body Section", Description="Body Section"},
            //                DisplayOrder = 4,
            //            },
            //            new SectionConfig
            //            {
            //                Id = 5,
            //                Section = new Section { Id = 5, Name = "Output Profile Section", Description="Output Profile Section"},
            //                DisplayOrder = 5,
            //            },
            //            new SectionConfig
            //            {
            //                Id = 6,
            //                Section = new Section { Id = 6, Name = "CC Section", Description="CC Section"},
            //                DisplayOrder = 6,
            //            },
            //        }
            //    }
            //    );
        }
    }
}
namespace Editor.Integration.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddednewPropertycolumn : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.PropertyConfig", "Value", c => c.String());
            DropColumn("dbo.PropertyConfig", "DisplayOrder");
        }
        
        public override void Down()
        {
            AddColumn("dbo.PropertyConfig", "DisplayOrder", c => c.Int(nullable: false));
            DropColumn("dbo.PropertyConfig", "Value");
        }
    }
}

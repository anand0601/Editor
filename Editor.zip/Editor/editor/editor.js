﻿
(function () {

    var app = angular.module('editor', ['ngRoute', 'ngResource', 'ngCookies']);

})();

angular.module('editor').controller('mainController', function ($scope) {
 
    $scope.HomeMessage = 'Home Controller Called !!!';
});

angular.module('editor').controller('aboutController', function ($scope) {
    $scope.AboutMessage = 'About Controller Called !!!';
});

angular.module('editor').controller('contactController', function ($scope) {
    $scope.ContactMessage = 'Contact Controller Called !!!';
});  

﻿(function () {



    angular.module('editor')
    .factory('letterService', ['$q', '$timeout', '$http','$cacheFactory', letterService]);

    function letterService($q, $timeout, $http,$cacheFactory) {

        //var letters = [];

        //var letters = [
        //             {
        //                 "id": 1,
        //                 "name": "A",
        //                 "description": "A"
        //             },
        //             {
        //                 "id": 2,
        //                 "name": "B",
        //                 "description": "B"
        //             },
        //             {
        //                 "id": 3,
        //                 "name": "C",
        //                 "description": "C"
        //             },
        //             {
        //                 "id": 4,
        //                 "name": "D",
        //                 "description": "D"
        //             }

        // ];

        return {
            getAllLetters: getAllLetters,
            getLetterByID: getLetterByID,
            addLetter: addLetter,
            updateLetter: updateLetter,
            deleteLetter: deleteLetter
        };


       

        //Get all Letters---------------------------------------------------------------------------------
        function getAllLetters() {

            //var lettersCache = $cacheFactory.get('allLettersCache');
            //if (!lettersCache) {

            //    lettersCache = $cacheFactory('allLettersCache');
            //}

            return $http({
                method: 'GET',
                url: 'http://localhost:27335/api/letters',
                header: {
                    'Anand-Prac-Editor-Version': '1.0.0.0'
                },
                cache: true
            })
            .then(sendResponseData)
            .catch(sendGetBookError)

            //var deferred = $q.defer();

            //$timeout(function () {
            //    var successful = true;
            //    if (successful) {


            //        deferred.notify('just getting started gathering letters');
            //        deferred.notify('Almost done gathering letters');


            //        deferred.resolve(letters);
            //    }
            //    else{

            //        deferred.reject('Error retrieving Letters');
            //    }

            //}, 1000);

            //return deferred.promise;
        }

        function deleteAllLetterResponseFromCache() {
            var httpCache = $cacheFactory.get('$http');
            //httpCache.remove('http://localhost:27335/api/letters');
            httpCache.removeAll();
            //var lettersCache = $cacheFactory.get('allLettersCache');
            //lettersCache.remove('allLettersCache');

        }

        //getting the letter by id-------------------------------------------------------------------------
        function getLetterByID(Id) {

            return $http({
                method: 'GET',
                url: 'http://localhost:27335/api/letters/' + Id,
                header: {
                    'Anand-Prac-Editor-Version': '1.0.0.0'
                },
                cache:true
            })
                .then(sendResponseData)
                .catch(sendGetBookError)
        }

        //Success and Error Call back functions for Get Methods
        function sendResponseData(response) {

            return response.data;
        }
        function sendGetBookError(response) {

            return $q.reject('Error retrieving Letter(s). (Http status: ' + response.status + ')');
        }



        //Add new Letter-----------------------------------------------------------------------------------
        function addLetter(newletter) {

            deleteAllLetterResponseFromCache();

            return $http({
                method: 'POST',
                url: 'http://localhost:27335/api/letters/',
                data: newletter,
                header: {
                    'Anand-Prac-Editor-Version': '1.0.0.0'
                }
            })
                .then(addLetterSuccess)
                .catch(addLetterError)
        }

        //Success and Error Call back functions for Add
        function addLetterSuccess(response) {

            return 'letter Added' + response.data.Name;
        }
        function addLetterError(response) {

            return $q.reject('Error adding Letter. (Http status: ' + response.status + ')');
        }

        //Update letter---------------------------------------------------------------------------------
        function updateLetter(letter) {

            deleteAllLetterResponseFromCache();

            return $http({
                method: 'PUT',
                url: 'http://localhost:27335/api/letters/' + letter.Id,
                data: letter,
                header: {
                    'Anand-Prac-Editor-Version': '1.0.0.0'
                }
            })
                .then(UpdateLetterSuccess)
                .catch(UpdateLetterError)
        }

        //Success and Error Call back functions for update
        function UpdateLetterSuccess(response) {

            return 'Letter Updated' + response.data.Name;
        }
        function UpdateLetterError(response) {

            return $q.reject('Error Updating Letter. (Http status: ' + response.status + ')');
        }


        //Delete letter-------------------------------------------------------------------------------
        function deleteLetter(id) {

            deleteAllLetterResponseFromCache();

            return $http({
                method: 'DELETE',
                url: 'http://localhost:27335/api/letters/' + id,
                header: {
                    'Anand-Prac-Editor-Version': '1.0.0.0'
                }
            })
                .then(deleteLetterSuccess)
                .catch(deleteLetterError)
        }

        //Success and Error Call back functions for Delete
        function deleteLetterSuccess(response) {

            return 'Letter Updated' + response.data.Name;
        }
        function deleteLetterError(response) {

            return $q.reject('Error Deleting letter. (Http status: ' + response.status + ')');
        }

    }

}());

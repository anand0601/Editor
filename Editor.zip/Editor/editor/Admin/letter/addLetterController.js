﻿(function () {

    angular.module('editor')
    .controller('addLetterController', ['letterService','$log','$location', addLetterController]);

    function addLetterController(letterService,$log,$location) {

        var vm = this;

        vm.addLetter = function () {

            letterService.addLetter(vm.newLetter)
                .then(addLetterSuccess)
                .catch(addLetterError)
        }

        //success call back function
        function addLetterSuccess(message) {
            $log.info(message);
            $location.path('/letters');
        }

        //error Call back function
        function addLetterError(errorMessage) {
            $log.error(errorMessage);
        }

    }


}());
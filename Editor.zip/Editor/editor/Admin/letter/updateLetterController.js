﻿(function () {

    angular.module('editor')
.controller('updateLetterController', ['$routeParams', '$log', '$cookies', '$cookieStore', 'letterService', '$location', updateLetterController]);

    function updateLetterController($routeParams, $log, $cookies, $cookieStore, letterService, $location) {

        var vm = this;

        //vm.currentLetter = letters.filter(function (item) {
        //    return item.id = $routeParams.id;
        //})[0];

        letterService.getLetterByID($routeParams.id)
        .then(getLetterSuccess)
        .catch(getLetterError)


        function getLetterSuccess(data) {
            vm.currentLetter = data;
        }

        function getLetterError(reason) {
            $log.error(reason);
        }


        //save method to Update letter 
        vm.saveLetter = function () {

            letterService.updateLetter(vm.currentLetter)
                .then(updateLetterSuccess)
                .catch(updateLetterError)
        }


        //success call back function
        function updateLetterSuccess(message) {
            $log.info(message);
            $location.path('/letters');
        }

        //error Call back function
        function updateLetterError(errorMessage) {
            $log.error(errorMessage);
        }



        vm.setAsFavorite = function () {

            $cookies.favoriteLetter = vm.currentLetter;

            $cookieStore.put('lastEdited', vm.currentLetter);
        }
    }


}());





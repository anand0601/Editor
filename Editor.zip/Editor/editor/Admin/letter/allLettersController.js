﻿(function () {

    angular.module("editor")
    .controller("allLettersController", ['letterService', '$log', '$route', '$routeParams', '$cookies', '$cookieStore', allLettersController]);

    function allLettersController(letterService, $log, $route, $routeParams, $cookies, $cookieStore) {
        var vm = this;

        vm.title = "all letters Controller text";

        vm.refresh = function () {
            alert('refresh called');
            $route.reload();
        }

        //vm.letters = allLetters;//letterService.getAllLetters(); 

        letterService.getAllLetters()
            //.then(getLettersSucces, getLettersError, getLettersNotification);
        .then(getLettersSucces, null, getLettersNotification)
        .catch(errorCallBack)
        .finally(getAllLettersComplete);


        function getLettersSucces(data) {

            //throw 'throw exception manualy';

            vm.letters = data;

            $log.log(vm.letters);
        }

        //function getLettersError(reason) {
        //    $log.log(reason);
        //}

        function errorCallBack(errorMsg) {
            console.log('Error Message : ' + errorMsg);
        }

        function getAllLettersComplete() {
            console.log('Get all Letters call Completed');
        }

        function getLettersNotification(notifications) {
            console.log('Promise notification ' + notifications);
        }

        //getting values from Cookies
        vm.favoriteLetter = $cookies.favoriteLetter;
        vm.lastEdited = $cookieStore.get('lastEdited');


        //Delete letter method
        vm.deleteLetter = function (id) {
            letterService.deleteLetter(id)
          .then(deleteLetterSuccess)
          .catch(deleteLetterError)

        };

        //Success and error call backs for Delete letter method 
        function deleteLetterSuccess(message) {
            $log.log(message);
            $route.reload();
        }
        function deleteLetterError(message) {
            $log.error(message);
            $route.reload();

        }

    }


}());

    

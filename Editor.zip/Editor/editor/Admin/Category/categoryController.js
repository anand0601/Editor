﻿angular.module('editor')
.controller('CategoryController', CategoryController);

function CategoryController($scope, $http, categoryService) {
    $scope.output = {};
    $scope.currentCategory = {};
    $scope.newCategory = {};
    $scope.categoryId = null;

    init();

    function init() {
        //categoryService.get()
        //.$promise
        //.then(function (response) {
        //    $scope.output = response;
        //    $scope.title = 'Got the Categories '
        //})
        //.catch(function () {
        //    $scope.title = "Oops... something went wrong"; $scope.working = false;
        //});

        $http.get('http://localhost:27335/api/category').success(function (data) {
            $scope.output = data;
            $scope.working = true;
        }).error(function (data) {
            $scope.title = "Oops... something went wrong";
            $scope.working = false;
        });
    }

    $scope.add = function () {
        $http.post('http://localhost:27335/api/category/', this.newCategory).success(function (data) {
            $scope.working = true;
        }).error(function (data) {
            $scope.title = "Oops... something went wrong";
            $scope.working = false;
        });
    }

    $scope.GetSelectedCategory = function (category) {
        $scope.currentCategory = category;
    }

    $scope.update = function (currentCategory) {
        $http.put('http://localhost:27335/api/category/', currentCategory).success(function (data) {
            $scope.working = true;
        }).error(function (data) {
            $scope.title = "Oops... something went wrong";
            $scope.working = false;
        });
    }

    $scope.deleteCat = function () {
        $http.delete('http://localhost:27335/api/category/', this.currentCategory).success(function (data) {
            $scope.working = true;
        }).error(function (data) {
            $scope.title = "Oops... something went wrong";
            $scope.working = false;
        });
    }
}
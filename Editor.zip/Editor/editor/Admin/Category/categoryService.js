﻿angular.module('editor')
.factory('categoryService', categoryService);

function categoryService($resource) {

    var resource = $resource('http://localhost:27335/api/category', { id: '@id' });
    return {
        get: function () {
            return resource.get();
        }

        //        create: { method: "POST" },
        //        get: { method: "GET", url: "/api/category?id=:id" },
        //        remove: { method: "DELETE", url: "/api/category?id=:id" },
        //        update: { method: "PUT", url: "/api/category?id=:id" }
    };


    //    return {

    //        getAll: function () {
    //            $http.get('http://localhost:37808/api/category').success(function (data) {
    //                $scope.output = data;
    //                $scope.working = true;
    //            }).error(function (data) {
    //                $scope.title = "Oops... something went wrong";
    //                $scope.working = false;
    //            });
    //        }

    //    }
}
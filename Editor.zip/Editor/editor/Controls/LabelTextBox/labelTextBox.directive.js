﻿angular.module('editor')
.directive('labelTextBox', labelTextBox);

function labelTextBox() {
    return {
        restrict: 'AE',
        templateUrl: "/editor/controls/labelTextBox/lableTextBox.htm",
        scope: {
            controlConfig: "=control"
        }
    }
}
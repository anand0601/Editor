﻿angular.module('editor')
.directive('labelDropDown', labelDropDown);

function labelDropDown() {
    return {
        restrict: 'AE',
        templateUrl: "/editor/controls/LabelDropDown/lableDropDown.htm",
        scope: {
            controlConfig: "=control"
        }
    }
}
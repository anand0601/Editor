﻿angular.module('editor')
.directive('labelCheckBox', labelCheckBox);

function labelCheckBox() {
    return {
        restrict: 'AE',
        templateUrl: "/editor/controls/labelCheckBox/labelCheckBox.htm",
        scope: {
            controlConfig: "=control"
        }
    }
}
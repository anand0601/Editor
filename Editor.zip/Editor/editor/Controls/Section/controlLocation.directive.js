﻿angular.module('editor')
.directive('controlLocator', controlLocator);

function controlLocator($compile) {
    var getTemplate = function (control) {
        var template = '';

        switch (control) {
            case 'LabelTextbox':
                template = '<label-text-box control="controlConfig" claims="claims" ></label-text-box>';
                break;
            case 'LabelDropDown':
                template = '<label-Drop-Down control="controlConfig"></label-Drop-Down>';
                break;
            case 'LabelCheckbox':
                template = '<label-check-box control="controlConfig"></label-check-box>';
                break;
        }

        return template;
    };

    var linker = function (scope, element, attrs) {
        var template = getTemplate(scope.controlConfig.Control.Name);
        element.html(template);
        $compile(element.contents())(scope);
    }

    return {
        restrict: 'AE',
        scope: {
            claims: "=",
            controlConfig: "=control"
        },
        link: linker
    }
}
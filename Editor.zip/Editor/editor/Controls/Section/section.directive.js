﻿

//angular.module('editor')
//.directive('sectionInfo', sectionInfo);

//function sectionInfo() {
//    return {
//        restrict: 'AE',
//        templateUrl: "/editor/controls/section/section.htm",
//        scope: {
//            sectionConfig: "=sectionConfig"
//        }//,
//        //controller: function ($scope) {
//        //    $scope.collapsed = ($scope.initialcollapsed === 'true');

//        //    $scope.Collapse = function () {
//        //        $scope.collapsed = !$scope.collapsed;
//        //    }
//        //}
//    }
//}

angular.module('editor')
.directive('sectionInfo', sectionInfo);

function sectionInfo() {
    return {
        restrict: 'AE',
        templateUrl: "/editor/controls/section/section.htm",
        scope: {
            claims: "=",
            sectionConfig: "=section",
            initialcollapsed: "@collapsed"
        },
        controller: function ($scope) {
            $scope.collapsed = ($scope.initialcollapsed === 'true');

            $scope.Collapse = function () {
                $scope.collapsed = !$scope.collapsed;
            }
        }
    }
}
﻿angular.module('editor')
.controller('CreateLetterController', CreateLetterController);

function CreateLetterController($scope, $http) {
    $scope.output = {};
    $scope.selectedCategory = {};
    $scope.selectedLetter = null;
    $scope.sections = {};


    init();

    function init() {

        $http.get('http://localhost:27335/api/category/getCategoriesWithLetters').success(function (data) {
            $scope.output = data;
            $scope.working = true;
        }).error(function (data) {
            $scope.title = "Oops... something went wrong";
            $scope.working = false;
        });
    }

    $scope.getSectionsForLetter = function () {
        if ($scope.selectedLetter != null) {

            $http.get('http://localhost:27335/api/section/getSectionsForLetter').success(function (data) {

                $scope.sections = data;
                $scope.working = true;
            }).error(function (data) {
                $scope.title = "Oops... something went wrong";
                $scope.working = false;
            });
        }

    }
}
﻿(function () {

    // configure our routes    
    angular.module('editor').config(function ($logProvider, $routeProvider, $locationProvider) {

        $logProvider.debugEnabled(true);

        //$locationProvider.hasPrefix("!");

        //$locationProvider.html5Mode({

        //    enabled: true,
        //    requireBase: true,
        //    rewriteLinks:true
        //});

        $routeProvider

        // route for the home page    
         .when('/home', {
             templateUrl: '/editor/main.htm',
             controller: 'mainController'
         })

        // route for the category Page   
        .when('/category', {
            templateUrl: '/editor/admin/category/category.htm',
            controller: 'contactController'
        })

        // route for the create letter page    
        .when('/createletter', {
            templateUrl: '/editor/createletter/createLetter.htm',
            controller: 'CreateLetterController'
        })

             // route for the letter   Page 
        .when('/letters', {
            templateUrl: '/editor/admin/letter/allLetters.htm',
            controller: 'allLettersController',
            controllerAs: 'vm',
            caseInsensitiveMatch: true
            //resolve: {
            //    allLetters: function (letterService) {
            //        return letterService.getAllLetters();
            //    }
            //,
            //letter: function (letterService) {
            //    return letterService.getLetter();
            //}
            //}
            //resolve: {
            //    promise: function () {
            //        throw 'error tranitioning to letters';
            //    }

            //}
        })
            .when('/letter/:id/details', {
                templateUrl: '/editor/admin/letter/letter.html',
                controller: 'letterController',
                controllerAs: 'vm',
                caseInsensitiveMatch: true
            })
            .when('/letter/addLetter', {
                templateUrl: '/editor/admin/letter/addLetter.html',
                controller: 'addLetterController',
                controllerAs: 'vm'
            })
               .when('/letter/updateLetter/:id', {
                   templateUrl: '/editor/admin/letter/updateLetter.html',
                   controller: 'updateLetterController',
                   controllerAs: 'vm'
                   //resolve: {
                   //    letters: function (letterService) {
                   //        return letterService.getAllLetters();

                   //    }
                   //}
               })

        // route for the help page    
        .when('/help', {
            templateUrl: '/editor/help.htm'
        })
        .otherwise('/');

    });


    angular.module("editor")
        .run(['$rootScope', '$log', function ($rootScope, $log) {

            $rootScope.$on('$routeChangeSuccess', function (event, current, previous) {

                $log.debug('succesfully changed routes');

                $log.debug(event);
                $log.debug(current);
                $log.debug(previous);

            });

            $rootScope.$on('$routeChangeError', function (event, current, previous, rejection) {

                $log.debug('error changing routes');

                $log.debug(event);
                $log.debug(current);
                $log.debug(previous);
                $log.debug(rejection);

            });

        }]);

}());


﻿using Editor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Editor.Core;
using Editor.Integration.Letters;

namespace Editor.Controllers
{
    public class LettersController : ApiController
    {
        // GET: api/Letter
        public IHttpActionResult Get()
        {
            var getlettersService = new GetLettersService();
            var letters = getlettersService.Execute();

            if (letters.Equals(null))
            {
                return NotFound();
            }

            return Ok(letters);
        }

        // GET: api/Letter/5
        public IHttpActionResult Get(int id)
        {
            var getletterService = new GetLetterService();
            var letter = getletterService.Execute(id);

            if (letter.Equals(null))
            {
                return NotFound();
            }

            return Ok(letter);
        }

        // POST: api/Letter
        public void Post([FromBody]Letter letter)
        {
            var addLetterService = new AddLetterService();

            addLetterService.Execute(letter);

        }

        // PUT: api/Letter/5
        public void Put(int id, [FromBody]Letter letter)
        {
            var updateLetterService = new UpdateLetterService();

            updateLetterService.Execute(letter);
        }

        // DELETE: api/Letter/5
        public void Delete(int id)
        {
            var deleteLetterService = new DeleteLetterService();

            deleteLetterService.Execute(id);
        }
    }
}

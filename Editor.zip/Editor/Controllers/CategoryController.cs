﻿using Editor.Core;
using Editor.Integration.Categories;
using Editor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Editor.Controllers
{

    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public int DepartmentId { get; set; }

        public int Salary { get; set; }
    }

    public class Department
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public List<Employee> EmpList { get; set; }


    }
    [RoutePrefix("api/category")]
    public class CategoryController : ApiController
    {
        // GET: api/Category


        public IOutput<List<Category>, string> Get()
        {

           // var Employees = new List<Employee>()
           //{
           //   new Employee() { Id=1, Name="Anand", DepartmentId  = 1, Salary=5000},
           //   new Employee() { Id=2, Name="Ravi", DepartmentId  = 1, Salary=6000},
           //   new Employee() { Id=3, Name="Sanjay", DepartmentId  = 2, Salary=4000},
           //   new Employee() { Id=4, Name="Rishabh", DepartmentId  = 2, Salary=4000}
           //};

           // var Departments = new List<Department>()
           //{
           //   new Department()
           //   { Id=1,
           //     Name ="Eng",
           //     EmpList =new List<Employee>()
           //     {
           //         new Employee() { Id=1, Name="Anand", DepartmentId  = 1, Salary=5000},
           //         new Employee() { Id=2, Name="Ravi", DepartmentId  = 1, Salary=6000}
           //     }
           //   },
           //   new Department()
           //   { Id=2,
           //     Name ="Sale",
           //     EmpList =new List<Employee>()
           //     {
           //         new Employee() { Id=3, Name="Sanjay", DepartmentId  = 2, Salary=4000},
           //         new Employee() { Id=4, Name="Rishabh", DepartmentId  = 2, Salary=4000}
           //     }
           //   },
           //   new Department()
           //   { Id=3,
           //     Name ="Marketing",
           //     EmpList =new List<Employee>()
           //     {
           //         new Employee() { Id=5, Name="Amit", DepartmentId  = 3, Salary=4000},
           //         new Employee() { Id=6, Name="Pankaj", DepartmentId  = 3, Salary=4000}
           //     }
           //   }
           //};

           // var query = Departments.SelectMany(d => d.EmpList,
           //                                     (d, e) => new { deptName = d.Name, EmpName = e.Name }
           //     ).ToList();



           // var queryByDept = from e in Employees
           //                   group e by e.DepartmentId
           //                   into empDept
           //                   select new { departmant = empDept.Key, EmpCount = empDept.Count() };


           // var queryByDeptExtension = Employees.Join(
           //                                     Departments,
           //                                     e => e.DepartmentId,
           //                                     d => d.Id,
           //                                     (e, d) => new
           //                                     {
           //                                         EmpName = e.Name,
           //                                         DeptName = d.Name
           //                                     }
           //                                     );


           // var queryBySalary = from e in Employees
           //                     group e
           //                     by new
           //                     {
           //                         e.DepartmentId,
           //                         empSalary = e.Salary
           //                     }
           //                   into empDept
           //                     select new
           //                     {
           //                         departmantId = empDept.Key.DepartmentId,
           //                         EmpSalary = empDept.Key.empSalary,
           //                         EmpCount = empDept.Count(),
           //                         employeeList = empDept
           //                     };

           // var queryByGroupSalarySum = from e in Employees
           //                             group e
           //                             by e.DepartmentId
           //            into empDept
           //                             select new
           //                             {
           //                                 departmantId = empDept.Key,
           //                                 EmpSalarySum = empDept.Sum(s => s.Salary),
           //                                 EmpCount = empDept.Count(),
           //                                 employeeList = empDept
           //                             };

           // var queryBySalaryWithExtension = Employees
           //     .GroupBy(e => new
           //     {
           //         e.DepartmentId,
           //         empSalary = e.Salary
           //     })
           //         .Select(g => new
           //         {
           //             departmantId = g.Key.DepartmentId,
           //             EmpSalary = g.Key.empSalary,
           //             EmpCount = g.Count(),
           //             empList = g
           //         });

           // var queryInnerJoin = from e in Employees
           //                      join d in Departments
           //                      on e.DepartmentId equals d.Id
           //                      select new
           //                      {
           //                          EmpName = e.Name,
           //                          DeptName = d.Name
           //                      };
           // var queryInnerJoinExtension = Employees.Join(Departments,
           //     e => e.DepartmentId,
           //     d => d.Id,
           //     (e, d) => new { EmpName = e.Name, Department = d.Name });


           // var queryLeftJoin = from d in Departments
           //                     join e in Employees
           //                     on d.Id equals e.DepartmentId
           //                     into de
           //                     select new
           //                     {
           //                         department = d.Name,
           //                         EmplList = de
           //                     };


           // var queryLeftJoinExtension = Departments.GroupJoin(Employees,
           //                                 d => d.Id,
           //                                 e => e.DepartmentId,
           //                                 (d, eg) => new
           //                                 {
           //                                     DeptName = d.Name,
           //                                     EmpList = eg,
           //                                     EmpSalarySum = eg.Sum(s => s.Salary)
           //                                 });



            var request = new Category();
            var input = new Input<Category>(request);

            var getCategoriesService = new GetCategoriesService();

            return getCategoriesService.Execute(input);
        }

        // GET: api/Category/5
        public IOutput<Category, string> Get(int id)
        {
            var request = new Category();
            var input = new Input<Category>(request);

            var getCategoryService = new GetCategoryService();
            return getCategoryService.Execute(input);
        }

        [HttpGet]
        [Route("getCategoriesWithLetters")]
        // GET: api/Category/getCategoriesWithLetters
        public IOutput<List<Category>, string> GetCategoriesWithLetters()
        {
            var request = new Category();
            var input = new Input<Category>(request);

            var getCategoriesWithLettersService = new GetCategoriesWithLettersService();
            return getCategoriesWithLettersService.Execute(input);
        }

        // POST: api/Category
        public IOutput<Category, string> Post([FromBody]Category category)
        {
            try
            {
                var c = category;
            }
            catch
            {
                return new Output<Category, string>(null, "Add" + category.Name);
            }

            return new Output<Category, string>(null, "Add" + category.Name);
        }

        // PUT: api/Category/5
        public IOutput<Category, string> Put([FromBody]Category category)
        {
            try
            {
                var c = category;
            }
            catch
            {
                return new Output<Category, string>(null, "Update" + category.Name);
            }

            return new Output<Category, string>(null, "Update" + category.Name);
        }

        // DELETE: api/Category/5
        public IOutput<Category, string> Delete(Category category)
        {
            try
            {
                var c = category;
            }
            catch
            {
                return new Output<Category, string>(null, "Delete" + category);
            }

            return new Output<Category, string>(null, "Delete" + category);
        }
    }
}

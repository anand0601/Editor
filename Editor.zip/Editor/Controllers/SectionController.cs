﻿using Editor.Core;
using Editor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Editor.Integration.Sections;

namespace Editor.Controllers
{
    [RoutePrefix("api/section")]
    public class SectionController : ApiController
    {
        // GET: api/Section
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Section/5
        public string Get(int id)
        {
            return "value";
        }

        [HttpGet]
        [Route("getSectionsForLetter")]
        // GET: api/Category/getSectionsForLetter
        public IOutput<List<SectionConfig>, string> GetSectionsForLetter()
        {
            var request = new Section();
            var input = new Input<Section>(request);

            var getSectionsForLetter = new GetSectionsForLetter();
            return getSectionsForLetter.Execute(input);
        }

        // POST: api/Section
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Section/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Section/5
        public void Delete(int id)
        {
        }
    }
}
